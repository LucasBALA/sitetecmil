function enviar() {
    window.alert('Aguarde enquanto sua mensagem está sendo enviada!')
}